<?php
class Test extends PHPUnit\Framework\TestCase
{
    public function testOne()
    {
        $this->assertTrue(true);
    }
}
